Tedlar Lead Agent — outreach drafts

Drag any .eml into Gmail to create a draft, or open Gmail and use
File > Import. Once you send it, MailSuite/Mailtrack tracks opens and
forwards automatically — no extra setup needed.

Recipient addresses are blank where no verified address was found.
They were deliberately not guessed.
